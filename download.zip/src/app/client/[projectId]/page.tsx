
"use client";

import { useEffect, useState, useMemo } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { ClientPhotoGrid } from '@/components/client/ClientPhotoGrid';
import { Button } from '@/components/ui/button';
import useLocalStorage from '@/hooks/useLocalStorage';
import type { Project, Photo } from '@/lib/types';
import { useToast } from "@/hooks/use-toast";
import { Send, CheckCircle, Image as ImageIcon, Loader2, Home } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import Image from 'next/image';

export default function ClientSelectionPage() {
  const params = useParams();
  const router = useRouter();
  const projectId = params.projectId as string;
  const initialProjectsValue = useMemo(() => [], []);
  const [projects, setProjects] = useLocalStorage<Project[]>('picworkflow-projects', initialProjectsValue);
  const [project, setProject] = useState<Project | null>(null);
  const [selectedPhotoIds, setSelectedPhotoIds] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    setIsLoading(true);
    const foundProject = projects.find(p => p.id === projectId);

    if (foundProject) {
      const photos = Array.isArray(foundProject.photos) ? foundProject.photos : [];
      
      const currentProjectState: Project = {
        ...foundProject,
        photos,
        selectedPhotoNames: Array.isArray(foundProject.selectedPhotoNames) ? foundProject.selectedPhotoNames : [],
      };
      setProject(currentProjectState);

      if (currentProjectState.status === "Selection Completed" &&
          currentProjectState.selectedPhotoNames &&
          currentProjectState.selectedPhotoNames.length > 0 &&
          photos.length > 0) {
        const initialSelectedIds = photos
          .filter(photo => currentProjectState.selectedPhotoNames!.includes(photo.name))
          .map(photo => photo.id);
        setSelectedPhotoIds(initialSelectedIds);
      } else {
        setSelectedPhotoIds([]);
      }
    } else {
      setProject(null);
      setSelectedPhotoIds([]);
    }
    setIsLoading(false);
  }, [projectId, projects]);

  const handleSelectionChange = (photoId: string, isSelected: boolean) => {
    if (project?.status === "Selection Completed") {
      toast({
        title: "Selection Finalized",
        description: "Selections cannot be changed after submission.",
        variant: "default"
      });
      return;
    }
    setSelectedPhotoIds(prev =>
      isSelected ? [...prev, photoId] : prev.filter(id => id !== photoId)
    );
  };

  const handleSubmitSelection = () => {
    if (!project) return;
    if (project.status === "Selection Completed") {
      toast({title: "Already Submitted", description: "This project's selections have already been finalized."});
      return;
    }
    setIsSubmitting(true);
    
    const selectedPhotosDetails = project.photos.filter(p => selectedPhotoIds.includes(p.id));
    const selectedOriginalNames = selectedPhotosDetails.map(p => p.name);

    const updatedProject: Project = {
      ...project,
      status: "Selection Completed",
      selectedPhotoNames: selectedOriginalNames,
      photos: project.photos.map(p => ({...p, selected: selectedPhotoIds.includes(p.id)}))
    };
    
    setProjects(prevProjects =>
      prevProjects.map(p => (p.id === projectId ? updatedProject : p))
    );
    setProject(updatedProject);
    
    setTimeout(() => {
        setIsSubmitting(false);
        toast({
          title: "Selection Sent!",
          description: `${selectedOriginalNames.length} photos have been sent to the photographer.`,
          variant: "default",
          className: "bg-green-500 text-white dark:bg-green-700"
        });
    }, 1000);
  };

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen p-4 bg-background">
        <Loader2 className="w-16 h-16 text-primary animate-spin" />
        <p className="mt-4 text-lg text-foreground font-body">Loading Project...</p>
      </div>
    );
  }

  if (!project) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen p-4 bg-background text-center">
         <div className="relative w-64 h-64 mb-6">
            <Image src="https://placehold.co/400x400.png" layout="fill" objectFit="contain" alt="Not found illustration" className="rounded-lg" data-ai-hint="magnifying glass error" />
        </div>
        <h1 className="text-3xl font-headline text-destructive mb-4">Project Not Found</h1>
        <p className="text-lg text-muted-foreground mb-6">The project you are looking for does not exist or the link is invalid.</p>
        <Button onClick={() => router.push('/')} variant="outline">
          <Home className="mr-2 h-4 w-4" /> Go to Homepage
        </Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="py-6 px-4 sm:px-8 shadow-md bg-card sticky top-0 z-20">
        <div className="container mx-auto">
          <h1 className="text-3xl sm:text-4xl font-headline text-primary text-center sm:text-left">
            {project.name}
          </h1>
          <p className="text-md sm:text-lg text-muted-foreground font-body text-center sm:text-left">
            Select your favorite photos
          </p>
        </div>
      </header>

      <main className="flex-grow container mx-auto p-4 sm:p-6">
        {project.status === "Selection Completed" && (
           <Alert variant="default" className="mb-6 bg-accent border-accent/50">
            <CheckCircle className="h-5 w-5 text-accent-foreground" />
            <AlertTitle className="font-headline text-accent-foreground">Selection Submitted!</AlertTitle>
            <AlertDescription className="text-accent-foreground">
              Your selection of {project.selectedPhotoNames?.length || 0} photos has been sent to the photographer. Thank you!
            </AlertDescription>
          </Alert>
        )}

        {project.photos.length === 0 && (
            <div className="text-center py-16 flex flex-col items-center justify-center bg-card shadow-lg rounded-lg">
                <ImageIcon className="w-24 h-24 mb-6 text-muted-foreground" />
                <h2 className="text-2xl font-headline mb-2 text-primary-foreground_on_card">No Photos Here Yet</h2>
                <p className="text-muted-foreground mb-6 max-w-md">
                The photographer hasn't uploaded any photos to this project. Please check back later or contact the photographer.
                </p>
            </div>
        )}
        
        {project.photos.length > 0 && (
            <ClientPhotoGrid
                photos={project.photos}
                selectedPhotos={selectedPhotoIds}
                onSelectionChange={handleSelectionChange}
            />
        )}
      </main>

      {project.photos.length > 0 && project.status !== "Selection Completed" && (
        <footer className="py-4 px-4 sm:px-8 border-t border-border bg-card sticky bottom-0 z-20 shadow-top">
          <div className="container mx-auto flex flex-col sm:flex-row justify-between items-center gap-4">
            <p className="text-lg font-semibold text-foreground">
              {selectedPhotoIds.length} photo(s) selected
            </p>
            <Button 
              size="lg" 
              onClick={handleSubmitSelection} 
              disabled={selectedPhotoIds.length === 0 || isSubmitting}
              className="w-full sm:w-auto transition-all duration-300 transform hover:scale-105"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" /> Sending...
                </>
              ) : (
                <>
                 <Send className="mr-2 h-5 w-5" /> Save & Send Selection
                </>
              )}
            </Button>
          </div>
        </footer>
      )}
       {project.status === "Selection Completed" && (
         <footer className="py-4 px-4 sm:px-8 border-t border-border bg-card">
          <div className="container mx-auto text-center">
            <p className="text-lg font-body text-green-600 dark:text-green-400">
              <CheckCircle className="inline-block mr-2 h-6 w-6 align-middle" />
              Your selections have been successfully submitted!
            </p>
          </div>
        </footer>
       )}
    </div>
  );
}
