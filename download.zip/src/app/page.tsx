
"use client";

import { useState, useEffect, useMemo } from 'react';
import { CreateProjectDialog } from '@/components/photographer/CreateProjectDialog';
import { ProjectItem } from '@/components/photographer/ProjectItem';
import useLocalStorage from '@/hooks/useLocalStorage';
import type { Project, Photo } from '@/lib/types';
import { Button } from '@/components/ui/button';
import { Camera, ListChecks, Wind, Check } from 'lucide-react';
import Image from 'next/image';

export default function PhotographerDashboardPage() {
  const initialProjects = useMemo(() => [], []);
  const [projects, setProjects] = useLocalStorage<Project[]>('picworkflow-projects', initialProjects);
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    setIsMounted(true);
  }, []);

  const handleCreateProject = (projectName: string) => {
    const newProject: Project = {
      id: crypto.randomUUID(),
      name: projectName,
      photos: [],
      status: "New",
      createdAt: new Date().toISOString(),
    };
    setProjects(prevProjects => [newProject, ...prevProjects]);
  };

  const handleUpdateProject = (updatedProject: Project) => {
    setProjects(prevProjects =>
      prevProjects.map(p => (p.id === updatedProject.id ? updatedProject : p))
    );
  };
  
  const handleDeleteProject = (projectId: string) => {
    if(window.confirm("Are you sure you want to delete this project? This cannot be undone.")) {
      setProjects(prevProjects => prevProjects.filter(p => p.id !== projectId));
    }
  };


  if (!isMounted) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen p-4 bg-background">
        <svg aria-hidden="true" className="w-16 h-16 text-primary animate-spin" viewBox="0 0 100 101" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z" fill="currentColor"/>
          <path d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0492C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 40.0354 89.3781 44.3852 89.0494 48.7079C88.6231 50.9601 90.0097 52.8876 92.2131 53.3769C92.9836 53.5608 93.7029 53.5152 94.3001 53.254L93.9676 39.0409Z" fill="hsl(var(--primary))"/>
        </svg>
        <p className="mt-4 text-lg text-foreground">Loading Wedding Photo Selection...</p>
      </div>
    );
  }

  const uniqueProjects = projects.filter((project, index, self) =>
    index === self.findIndex((p) => p.id === project.id)
  );

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header
        className="relative py-12 sm:py-20 px-4 sm:px-8 shadow-lg bg-cover bg-center bg-[url('https://placehold.co/1600x600.png')]"
        data-ai-hint="wedding venue elegant" 
      >
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/50 to-transparent"></div> {/* Gradient Overlay */}
        <div className="container mx-auto flex flex-col sm:flex-row justify-between items-center relative z-10">
          <div className="text-center sm:text-left">
            <h1 className="text-4xl sm:text-5xl font-headline text-white flex items-center justify-center sm:justify-start drop-shadow-md">
              <Check className="mr-3 h-9 w-9" />
              Wedding Photo Selection
            </h1>
            <p className="text-lg sm:text-xl text-gray-200 font-body drop-shadow-sm">
              Wedding Photo Selection, Simplified.
            </p>
          </div>
          <div className="mt-6 sm:mt-0">
            <CreateProjectDialog onCreateProject={handleCreateProject} />
          </div>
        </div>
      </header>

      <main className="flex-grow container mx-auto p-4 sm:p-8">
        {uniqueProjects.length === 0 ? (
          <div className="text-center py-16 flex flex-col items-center justify-center bg-card shadow-lg rounded-lg">
            <div className="relative w-48 h-48 mb-6">
                <Image src="https://placehold.co/300x300.png" layout="fill" objectFit="contain" alt="Empty state illustration" className="rounded-lg" data-ai-hint="camera illustration"/>
            </div>
            <h2 className="text-2xl font-headline mb-2 text-primary-foreground_on_card">No Projects Yet!</h2>
            <p className="text-muted-foreground mb-6 max-w-md">
              Ready to streamline your photo selection process? Click "Create New Project" to get started.
              Upload your photos, generate a unique link for your client, and receive their selections effortlessly.
            </p>
            <CreateProjectDialog onCreateProject={handleCreateProject} />
          </div>
        ) : (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {uniqueProjects.map(project => (
              <ProjectItem
                key={project.id}
                project={project}
                onUpdateProject={handleUpdateProject}
                onDeleteProject={handleDeleteProject}
              />
            ))}
          </div>
        )}
      </main>
      <footer className="py-6 text-center text-muted-foreground text-sm border-t border-border bg-card">
        <p>&copy; {new Date().getFullYear()} Wedding Photo Selection. All rights reserved.</p>
        <p className="font-headline">Elegance in Every Click</p>
        <p>Made by Sushil Verma</p>
      </footer>
    </div>
  );
}
