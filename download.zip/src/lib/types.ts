export interface Photo {
  id: string; // Unique ID for the photo within a project
  name: string; // Original file name
  url: string; // Data URL for preview
  selected: boolean;
}

export type ProjectStatus = "New" | "Photos Uploaded" | "Under Selection" | "Selection Completed";

export interface Project {
  id: string; // Unique ID for the project
  name: string;
  photos: Photo[];
  status: ProjectStatus;
  clientLink?: string;
  selectedPhotoNames?: string[]; // Store only names for .bat file
  createdAt: string; // ISO date string
}
