
"use client";

import Image from 'next/image';
import { Checkbox } from "@/components/ui/checkbox";
import type { Photo } from '@/lib/types';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { ZoomIn } from 'lucide-react';
import { Button } from "@/components/ui/button"; // Added import
import {
  Dialog,
  DialogContent,
  DialogTrigger,
} from "@/components/ui/dialog";

interface ClientPhotoGridProps {
  photos: Photo[];
  selectedPhotos: string[]; // array of photo IDs
  onSelectionChange: (photoId: string,isSelected: boolean) => void;
}

export function ClientPhotoGrid({ photos, selectedPhotos, onSelectionChange }: ClientPhotoGridProps) {
  if (!photos || photos.length === 0) {
    return <p className="text-center text-muted-foreground py-10">No photos available in this project yet.</p>;
  }

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 sm:gap-4 p-2">
      {photos.map((photo) => {
        const isSelected = selectedPhotos.includes(photo.id);
        return (
          <Card 
            key={photo.id} 
            className={`relative group overflow-hidden shadow-md hover:shadow-lg transition-all duration-300 rounded-lg aspect-square
                        ${isSelected ? 'ring-4 ring-primary ring-offset-2' : 'ring-1 ring-border'}`}
          >
            <Label htmlFor={`photo-${photo.id}`} className="block w-full h-full cursor-pointer">
              <Image
                src={photo.url}
                alt={`Preview of ${photo.name}`}
                layout="fill"
                objectFit="cover"
                className={`transition-transform duration-300 group-hover:scale-105 ${isSelected ? 'opacity-80' : ''}`}
                data-ai-hint="wedding photograph"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-2">
                <p className="text-xs text-white truncate">{photo.name}</p>
              </div>
            </Label>
            <div className="absolute top-2 right-2 z-10">
              <Checkbox
                id={`photo-${photo.id}`}
                checked={isSelected}
                onCheckedChange={(checked) => onSelectionChange(photo.id, !!checked)}
                className="bg-background/80 hover:bg-background border-border data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground h-6 w-6 rounded"
                aria-label={`Select ${photo.name}`}
              />
            </div>
             <Dialog>
                <DialogTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="absolute bottom-2 right-2 z-10 h-8 w-8 bg-black/50 text-white hover:bg-black/70 hover:text-white opacity-0 group-hover:opacity-100 transition-opacity rounded-full"
                    aria-label="Zoom in on photo"
                  >
                    <ZoomIn className="h-5 w-5" />
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-3xl max-h-[90vh] p-2 sm:p-4 bg-background">
                  <div className="relative w-full aspect-video">
                     <Image src={photo.url} alt={`Enlarged view of ${photo.name}`} layout="fill" objectFit="contain" />
                  </div>
                   <p className="text-center text-sm text-muted-foreground mt-2">{photo.name}</p>
                </DialogContent>
              </Dialog>
          </Card>
        );
      })}
    </div>
  );
}
