
"use client";

import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button, buttonVariants } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { PhotoUploadDialog } from './PhotoUploadDialog';
import { useToast } from "@/hooks/use-toast";
import type { Project, Photo, ProjectStatus } from '@/lib/types';
import { Upload, Link2, Download, Eye, AlertTriangle, Trash2 } from 'lucide-react';
import { format } from 'date-fns';

interface ProjectItemProps {
  project: Project;
  onUpdateProject: (updatedProject: Project) => void;
  onDeleteProject: (projectId: string) => void;
}

export function ProjectItem({ project, onUpdateProject, onDeleteProject }: ProjectItemProps) {
  const [isUploadDialogOpen, setIsUploadDialogOpen] = useState(false);
  const { toast } = useToast();
  const router = useRouter();

  const handlePhotosUploaded = (projectId: string, photos: Photo[]) => {
    if (project.id === projectId) {
      onUpdateProject({ ...project, photos, status: "Photos Uploaded" });
    }
  };

  const handleClientAccessActions = () => {
    let targetClientLink = project.clientLink;
    const wasPhotosUploadedStatus = project.status === "Photos Uploaded";

    if (!targetClientLink || project.status === "Photos Uploaded") {
      targetClientLink = `${window.location.origin}/client/${project.id}`;
      onUpdateProject({
        ...project,
        clientLink: targetClientLink,
        status: "Under Selection",
      });
    } else if (project.status !== "Under Selection") {
      onUpdateProject({ ...project, status: "Under Selection" });
    }

    toast({
      title: wasPhotosUploadedStatus || !project.clientLink ? "Client Link Generated & Activated!" : "Client Link Ready",
      description: (
        <div>
          <p>You can share this link with your client:</p>
          <input
            type="text"
            readOnly
            value={targetClientLink!}
            className="mt-2 w-full p-2 border rounded bg-muted text-sm"
            onFocus={(e) => e.target.select()}
          />
          <p className="mt-2 text-xs text-muted-foreground">You are now being navigated to the client view.</p>
        </div>
      ),
      duration: 10000,
    });

    if (targetClientLink) {
      router.push(targetClientLink);
    }
  };

  const generateBatContent = (projectName: string, selectedPhotoNames: string[]) => {
    const safeProjectName = projectName.replace(/[^a-zA-Z0-9_]/g, '_');
    let content = `@echo off\n`;
    content += `title Processing ${safeProjectName} Selections\n`;
    content += `echo Creating folder for selected photos...\n`;
    content += `mkdir "Selected_Photos_${safeProjectName}"\n\n`;
    content += `echo Copying selected photos...\n`;
    selectedPhotoNames.forEach(name => {
      content += `copy "${name}" "Selected_Photos_${safeProjectName}\\${name}"\n`;
    });
    content += `\necho.\n`;
    content += `echo ==========================================================\n`;
    content += `echo   ${selectedPhotoNames.length} photos copied to "Selected_Photos_${safeProjectName}" folder.\n`;
    content += `echo   This window will close automatically.\n`;
    content += `echo ==========================================================\n`;
    content += `timeout /t 5 /nobreak > nul\n`;
    return content;
  };

  const handleDownloadBatFile = () => {
    if (!project.selectedPhotoNames || project.selectedPhotoNames.length === 0) {
      toast({ title: "No photos selected by client.", variant: "destructive" });
      return;
    }
    const batContent = generateBatContent(project.name, project.selectedPhotoNames);
    const safeProjectName = project.name.replace(/[^a-zA-Z0-9_]/g, '_');
    const blob = new Blob([batContent], { type: 'text/plain' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `copy_selected_${safeProjectName}.bat`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(link.href);
    toast({ title: ".bat File Downloaded", description: "Run the file in your original photos folder." });
  };
  
  const getStatusColor = (status: ProjectStatus) => {
    switch (status) {
      case "New": return "bg-blue-500";
      case "Photos Uploaded": return "bg-yellow-500";
      case "Under Selection": return "bg-orange-500";
      case "Selection Completed": return "bg-green-500";
      default: return "bg-gray-500";
    }
  };


  return (
    <Card className="w-full shadow-lg hover:shadow-xl transition-shadow duration-300 bg-card flex flex-col">
      <CardHeader>
        <div className="flex justify-between items-start">
          <CardTitle className="font-headline text-2xl text-primary-foreground_on_card">{project.name}</CardTitle>
          <Badge variant="secondary" className={`${getStatusColor(project.status)} text-primary-foreground`}>
            {project.status}
          </Badge>
        </div>
        <CardDescription>Created: {format(new Date(project.createdAt), "MMMM d, yyyy 'at' h:mm a")}</CardDescription>
      </CardHeader>
      <CardContent className="flex-grow">
        {project.status === "Under Selection" && project.clientLink && (
          <Alert variant="default" className="mb-4 bg-accent/30 border-accent">
            <Link2 className="h-4 w-4 text-accent-foreground" />
            <AlertTitle className="text-accent-foreground font-semibold">Client Link Active</AlertTitle>
            <AlertDescription className="text-accent-foreground">
              Client can access photos at: <a href={project.clientLink} target="_blank" rel="noopener noreferrer" className="underline hover:opacity-80">{project.clientLink}</a>
              <Button size="sm" variant="ghost" className="ml-2 text-accent-foreground" onClick={() => navigator.clipboard.writeText(project.clientLink || "").then(() => toast({title: "Link Copied!"}))}>Copy Link</Button>
            </AlertDescription>
          </Alert>
        )}
         {project.status === "Selection Completed" && (
          <Alert variant="default" className="mb-4 bg-green-100 border-green-400 dark:bg-green-900 dark:border-green-700">
            <Eye className="h-4 w-4 text-green-700 dark:text-green-300" />
            <AlertTitle className="text-green-800 dark:text-green-200 font-semibold">Selection Completed by Client!</AlertTitle>
            <AlertDescription className="text-green-700 dark:text-green-300">
              {project.selectedPhotoNames?.length || 0} photos selected. You can now download the .bat file.
            </AlertDescription>
          </Alert>
        )}

        <p className="text-sm text-muted-foreground">Photos: {project.photos.length}</p>
        {project.photos.length > 0 && (
             <div className="mt-2 flex flex-wrap gap-2 max-h-24 overflow-y-auto p-1 rounded-md bg-muted/30">
                {project.photos.slice(0, 5).map(photo => (
                    <div key={photo.id} className="w-16 h-16 rounded overflow-hidden border border-border">
                         <img src={photo.url} alt={photo.name} className="w-full h-full object-cover" data-ai-hint="thumbnail image" />
                    </div>
                ))}
                {project.photos.length > 5 && <div className="w-16 h-16 rounded bg-muted flex items-center justify-center text-xs text-muted-foreground">+{project.photos.length - 5} more</div>}
            </div>
        )}
      </CardContent>
      <CardFooter className="flex flex-col sm:flex-row justify-between items-center gap-2 pt-4 mt-auto">
        <Button 
            variant="outline" 
            size="sm"
            onClick={() => onDeleteProject(project.id)}
            className="text-destructive hover:bg-destructive/10 border-destructive/50 hover:text-destructive"
            aria-label={`Delete project ${project.name}`}
            >
            <Trash2 className="mr-2 h-4 w-4" /> Delete Project
        </Button>
        <div className="flex gap-2">
            {project.status === "New" && (
            <Button onClick={() => setIsUploadDialogOpen(true)}>
                <Upload className="mr-2 h-4 w-4" /> Upload Photos
            </Button>
            )}
            {(project.status === "Photos Uploaded" || project.status === "Under Selection") && (
            <Button onClick={handleClientAccessActions}>
                <Eye className="mr-2 h-4 w-4" />
                {project.status === "Photos Uploaded" ? "Generate Link & View" : "Get Link"}
            </Button>
            )}
            {project.status === "Selection Completed" && (
            <Button onClick={handleDownloadBatFile} disabled={!project.selectedPhotoNames || project.selectedPhotoNames.length === 0}>
                <Download className="mr-2 h-4 w-4" /> Download .bat File
                {(!project.selectedPhotoNames || project.selectedPhotoNames.length === 0) && <AlertTriangle className="ml-2 h-4 w-4 text-yellow-400" />}
            </Button>
            )}
        </div>
      </CardFooter>

      <PhotoUploadDialog
        projectId={project.id}
        projectName={project.name}
        isOpen={isUploadDialogOpen}
        onOpenChange={setIsUploadDialogOpen}
        onPhotosUploaded={handlePhotosUploaded}
      />
    </Card>
  );
}
