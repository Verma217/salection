
"use client";

import { useState, ChangeEvent, useRef } from 'react';
import Image from 'next/image';
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import { UploadCloud, FileImage, X, Loader2 } from "lucide-react";
import type { Photo } from '@/lib/types';

interface PhotoUploadDialogProps {
  projectId: string;
  projectName: string;
  isOpen: boolean;
  onOpenChange: (isOpen: boolean) => void;
  onPhotosUploaded: (projectId: string, photos: Photo[]) => void;
}

interface FilePreview {
  id: string;
  name: string;
  url: string;
  file: File; // Original file, kept for potential future use, not stored in localStorage
}

// Helper function to resize images client-side
const resizeImage = (file: File, maxWidth: number, maxHeight: number, quality: number): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      if (!event.target?.result) {
        return reject(new Error("FileReader did not return a result."));
      }
      const img = document.createElement('img');
      img.onload = () => {
        let { width, height } = img;
        const ratio = width / height;

        if (width > maxWidth) {
          width = maxWidth;
          height = Math.round(width / ratio);
        }
        if (height > maxHeight) {
          height = maxHeight;
          width = Math.round(height * ratio);
        }
        
        width = Math.max(1, Math.round(width));
        height = Math.max(1, Math.round(height));


        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          return reject(new Error('Failed to get canvas context'));
        }
        ctx.imageSmoothingQuality = 'medium';
        ctx.drawImage(img, 0, 0, width, height);
        
        // Use image/jpeg for better compression for photos
        resolve(canvas.toDataURL('image/jpeg', quality));
      };
      img.onerror = (err) => reject(new Error('Image load error: ' + err));
      img.src = event.target.result as string;
    };
    reader.onerror = (err) => reject(new Error('FileReader error: ' + err));
    reader.readAsDataURL(file);
  });
};

export function PhotoUploadDialog({
  projectId,
  projectName,
  isOpen,
  onOpenChange,
  onPhotosUploaded,
}: PhotoUploadDialogProps) {
  const [filePreviews, setFilePreviews] = useState<FilePreview[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false); // For image resizing
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleFileChange = async (event: ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files && files.length > 0) {
      setIsProcessing(true);
      const newFilePreviewsPromises = Array.from(files).map(async (file): Promise<FilePreview | null> => {
        if (!file.type.startsWith('image/')) {
          toast({
            title: "Invalid File Type",
            description: `${file.name} is not an image and will be ignored.`,
            variant: "destructive",
          });
          return null;
        }
        try {
          // Resize to max 600x600, 70% JPEG quality
          const resizedDataUrl = await resizeImage(file, 600, 600, 0.7);
          return {
            id: crypto.randomUUID(),
            name: file.name,
            url: resizedDataUrl,
            file: file,
          };
        } catch (error) {
          console.error("Error resizing image:", file.name, error);
          toast({
            title: "Image Processing Error",
            description: `Could not process ${file.name}. It might be corrupted or an unsupported format. Skipped.`,
            variant: "destructive",
          });
          return null;
        }
      });

      const results = await Promise.all(newFilePreviewsPromises);
      const successfulPreviews = results.filter(p => p !== null) as FilePreview[];
      
      if (successfulPreviews.length > 0) {
        setFilePreviews(prev => [...prev, ...successfulPreviews]);
      }
      
      setIsProcessing(false);

      if (fileInputRef.current) {
        fileInputRef.current.value = ""; // Clear input to allow re-selection of same files
      }
    }
  };

  const removeFilePreview = (id: string) => {
    setFilePreviews(prev => prev.filter(fp => fp.id !== id));
  };

  const handleUpload = async () => {
    if (filePreviews.length === 0) {
      toast({ title: "No photos selected", description: "Please select photos to upload."});
      return;
    }
    setIsUploading(true);
    
    const uploadedPhotos: Photo[] = filePreviews.map(fp => ({
      id: fp.id, // This is already a UUID
      name: fp.name,
      url: fp.url, // This is the resized data URL
      selected: false,
    }));

    await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate network delay

    onPhotosUploaded(projectId, uploadedPhotos);
    setIsUploading(false);
    setFilePreviews([]);
    onOpenChange(false);
    toast({ title: "Photos Uploaded", description: `${uploadedPhotos.length} photos added to ${projectName}.` });
  };
  
  const openFileDialog = () => {
    if (isProcessing || isUploading) return;
    fileInputRef.current?.click();
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => {
      if (isProcessing || isUploading) return; // Prevent closing while busy
      onOpenChange(open);
      if (!open) setFilePreviews([]); // Clear previews if dialog is closed manually
    }}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] flex flex-col bg-card">
        <DialogHeader>
          <DialogTitle className="font-headline text-2xl">Upload Photos to "{projectName}"</DialogTitle>
          <DialogDescription>
            Select photos from your computer. Optimized previews will be generated for client selection.
          </DialogDescription>
        </DialogHeader>

        <div className="flex-grow flex flex-col gap-4 py-4 overflow-hidden">
          <Button onClick={openFileDialog} variant="outline" className="w-full" disabled={isProcessing || isUploading}>
            {isProcessing ? (
              <><Loader2 className="mr-2 h-5 w-5 animate-spin" /> Processing Images...</>
            ) : (
              <><UploadCloud className="mr-2 h-5 w-5" /> Select Photos</>
            )}
            
          </Button>
          <Input
            ref={fileInputRef}
            id="photo-upload-input"
            type="file"
            multiple
            accept="image/*"
            onChange={handleFileChange}
            className="hidden"
            aria-label="Photo upload input"
            disabled={isProcessing || isUploading}
          />

          {filePreviews.length > 0 && (
            <ScrollArea className="flex-grow h-64 border rounded-md p-2 bg-muted/50">
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
                {filePreviews.map((fp) => (
                  <div key={fp.id} className="relative group aspect-square border rounded-md overflow-hidden shadow-md">
                    <Image
                      src={fp.url}
                      alt={`Preview of ${fp.name}`}
                      layout="fill"
                      objectFit="cover"
                      data-ai-hint="photograph event"
                    />
                    <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center p-1">
                      <Button
                        variant="destructive"
                        size="icon"
                        className="absolute top-1 right-1 h-6 w-6"
                        onClick={() => removeFilePreview(fp.id)}
                        aria-label={`Remove ${fp.name}`}
                        disabled={isProcessing || isUploading}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                      <p className="text-xs text-white text-center truncate w-full px-1 absolute bottom-1 bg-black/70 py-0.5 rounded-sm">
                        {fp.name}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          )}
          {filePreviews.length === 0 && !isProcessing && (
             <div className="flex-grow flex flex-col items-center justify-center border-2 border-dashed border-border rounded-md p-8 text-muted-foreground">
                <FileImage className="w-16 h-16 mb-4" />
                <p className="font-semibold">No photos selected yet.</p>
                <p className="text-sm">Click "Select Photos" to begin.</p>
            </div>
          )}
           {filePreviews.length === 0 && isProcessing && (
             <div className="flex-grow flex flex-col items-center justify-center border-2 border-dashed border-border rounded-md p-8 text-muted-foreground">
                <Loader2 className="w-16 h-16 mb-4 animate-spin text-primary" />
                <p className="font-semibold">Processing images...</p>
                <p className="text-sm">Please wait.</p>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={isUploading || isProcessing}>
            Cancel
          </Button>
          <Button onClick={handleUpload} disabled={filePreviews.length === 0 || isUploading || isProcessing}>
            {isUploading ? (
              <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Uploading...</>
            ) : isProcessing ? (
              <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Processing...</>
            ) : (
              `Upload ${filePreviews.length} Photo(s)`
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
