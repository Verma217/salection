
"use client";
import { useState, useEffect, useCallback, Dispatch, SetStateAction } from 'react';

type SetValue<T> = Dispatch<SetStateAction<T>>;

function useLocalStorage<T>(key: string, initialValue: T): [T, SetValue<T>] {
  // Helper to read value from storage, memoized with useCallback
  const readValue = useCallback((): T => {
    // Prevent build errors and console warnings in server environments.
    if (typeof window === 'undefined') {
      return initialValue;
    }
    try {
      const item = window.localStorage.getItem(key);
      return item ? (JSON.parse(item) as T) : initialValue;
    } catch (error) {
      console.warn(`Error reading localStorage key “${key}”:`, error);
      return initialValue;
    }
  }, [initialValue, key]);

  // State to store our value.
  // Pass a function to useState so logic is only executed once on the client-side.
  const [storedValue, setStoredValue] = useState<T>(readValue);

  // The setValue function persists the new value to localStorage.
  const setValue: SetValue<T> = useCallback(
    (valueOrFn) => {
      if (typeof window === 'undefined') {
        console.warn(
          `Tried to set localStorage key “${key}” even though window is not defined.`
        );
        return;
      }

      setStoredValue(currentStoredValue => {
          const newValue = valueOrFn instanceof Function ? valueOrFn(currentStoredValue) : valueOrFn;
          try {
            window.localStorage.setItem(key, JSON.stringify(newValue));
            // Dispatch a custom event so every useLocalStorage hook instance is notified of the change in the same tab.
            // The native 'storage' event only fires for changes in other tabs/windows.
            window.dispatchEvent(new StorageEvent('local-storage', { key, newValue: JSON.stringify(newValue) }));
          } catch (error) {
            console.warn(`Error setting localStorage key “${key}”:`, error);
          }
          return newValue;
      });
    },
    [key] 
  );
  
  // This effect ensures that the state is updated from localStorage after initial mount on client,
  // and if the key or initialValue were to change (though typically stable for this hook's use case).
  useEffect(() => {
    setStoredValue(readValue());
  }, [readValue]); // readValue dependency will re-run if key or initialValue changes

  // Effect to listen for storage events (cross-tab synchronization and same-tab custom event)
  useEffect(() => {
    if (typeof window === 'undefined') return;

    const handleStorageChange = (event: StorageEvent) => {
      if ((event.type === 'storage' || event.type === 'local-storage') && event.key === key) {
        if (event.newValue === null) { // Item was removed from localStorage
             setStoredValue(initialValue);
        } else {
            try {
                // event.newValue is a string or null
                setStoredValue(JSON.parse(event.newValue as string) as T);
            } catch {
                setStoredValue(initialValue); // Fallback if parsing fails
            }
        }
      }
    };

    window.addEventListener('storage', handleStorageChange);
    window.addEventListener('local-storage', handleStorageChange as EventListener); // Need to cast for custom event

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('local-storage', handleStorageChange as EventListener);
    };
  }, [key, initialValue, readValue]); // Ensure all dependencies that might change readValue or initialValue are listed

  return [storedValue, setValue];
}

export default useLocalStorage;
